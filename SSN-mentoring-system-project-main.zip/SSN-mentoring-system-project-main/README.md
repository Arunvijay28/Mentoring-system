# SSN-mentoring-system-project
<!--project statement: 
11. An organization like SSN College of Engineering wants to develop a mentoring system. A
mentor should be able to view all the mentees assigned to them. On selecting a mentee, the
mentor should be able to add/delete/update the mentee details. The mentor may schedule a
meeting with a mentee and should be able to capture the meeting details later. A mentee
should be able to see only their details, except for the confidential information entered by the
mentor. A mentee should be able to request for a meeting with the mentor through this
system. The manager should be able to generate various reports from these mentee records -->